from fibo import fib, fib2
fib(500)

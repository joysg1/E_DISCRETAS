palabras = ['gato', 'ventana', 'defenestrar']
for p in palabras:
    print(p, len(p))

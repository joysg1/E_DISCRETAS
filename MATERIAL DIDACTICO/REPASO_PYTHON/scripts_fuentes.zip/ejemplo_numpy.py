import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable

def f(z):
    return np.square(z) - 1

z = [4, 1-0.2j, 1.6]
print(f(z))

x, y = np.meshgrid(np.linspace(-10, 10, 20), np.linspace(-10, 10, 20))
mesh = x + (1j * y)  # Crear una malla de plano complejo

output = np.abs(f(mesh))  # Tomar el valor absoluto de la salida (para graficar)

fig = plt.figure()
ax = plt.axes(projection='3d')

ax.scatter(x, y, output, alpha=0.2)

ax.set_xlabel('Eje real')
ax.set_ylabel('Eje imaginario')
ax.set_zlabel('Valor absoluto')
ax.set_title('Una Iteracion: $ f(z) = z^2 - 1$');

plt.savefig("plot.pdf", format="pdf")
plt.show()

nombre = "Juan"
apellido = "Garcia"
print(f"Mi nombre es {nombre} {apellido}")

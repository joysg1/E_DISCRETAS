import nltk
# nltk.download('universal_tagset')
from nltk.corpus import cess_esp

nltk.tag.mapping._load_universal_map("es-cast3lb")  # initialize; normally loaded on demand
mapdict = nltk.tag.mapping._MAPPINGS["es-cast3lb"]["universal"] # shortcut to the map

alltags = set(t for w, t in cess_esp.tagged_words())
for tag in alltags:
    if len(tag) <= 2:   # These are complete
        continue
    mapdict[tag] = mapdict[tag[:2]]

# cess_esp._tagset = "es-ancora"
cess_esp._tagset = "es-cast3lb"
oraciones = cess_esp.tagged_sents(tagset="universal")
# oraciones = cess_esp.tagged_sents()
print(oraciones[0])



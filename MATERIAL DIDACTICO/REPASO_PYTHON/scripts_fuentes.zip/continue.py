for num in range(2, 10):
    if num % 2 == 0:
        print("Número par ", num)
        continue
    print("Número impar ", num)

import math
print(math.cos(math.pi / 4))
print(math.log(1024, 2))

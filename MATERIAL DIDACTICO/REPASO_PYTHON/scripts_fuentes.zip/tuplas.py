t = 12345, 54321, 'hello!'
print(t[0])
print(t)

# Las tuplas pueden ser anidadas:
u = t, (1, 2, 3, 4, 5)
print(u)

# Las tuplas son imutables:
t[0] = 88888

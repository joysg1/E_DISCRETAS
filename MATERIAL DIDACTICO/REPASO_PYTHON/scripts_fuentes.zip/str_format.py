num_arboles = 1300
prom_crecimiento = 1.4948
print("Los {:,} arboles crecen {:6.2f} cm por año".format(num_arboles, prom_crecimiento))

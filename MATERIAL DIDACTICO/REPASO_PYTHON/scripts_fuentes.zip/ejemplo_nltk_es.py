# import nltk
# from nltk.corpus import cess_esp as cess
# nltk.download('punkt')
# nltk.download('averaged_perceptron_tagger')
# # sentence = """At eight o'clock on Thursday morning... Arthur didn't feel very good."""
# sentence = """A las ocho en punto el jueves en la mañana... Arturo no se sentía muy bien."""
# tokens = nltk.word_tokenize(sentence)
# print(tokens)
# tagged = nltk.pos_tag(tokens)
# print(tagged[0:6])

import nltk
# nltk.download('cess_esp')
# nltk.download('universal_tagset')

from nltk.corpus import cess_esp as cess
from nltk import UnigramTagger as ut
from nltk import BigramTagger as bt

# Read the corpus into a list, 
# each entry in the list is one sentence.
# cess_sents = cess.tagged_sents()

nltk.tag.mapping._load_universal_map("es-cast3lb")  # initialize; normally loaded on demand
mapdict = nltk.tag.mapping._MAPPINGS["es-cast3lb"]["universal"] # shortcut to the map

alltags = set(t for w, t in cess.tagged_words())
for tag in alltags:
    if len(tag) <= 2:   # These are complete
        continue
    mapdict[tag] = mapdict[tag[:2]]

# cess_esp._tagset = "es-ancora"
cess._tagset = "es-cast3lb"
# oraciones = cess.tagged_sents(tagset="universal")
cess_sents = cess.tagged_sents(tagset="universal")


# Train the unigram tagger
uni_tag = ut(cess_sents)

sentence = "Hola, esta foo bar."

# print(cess_sents[0])

# Tagger reads a list of tokens.
print("read tokens: ")
print(uni_tag.tag(sentence.split(" ")))

# Split corpus into training and testing set.
train = int(len(cess_sents)*90/100) # 90%

# Train a bigram tagger with only training data.
# bi_tag = bt(cess_sents[:train])
bi_tag = bt(cess_sents[:train], backoff=uni_tag)

# Evaluates on testing data remaining 10%
# bi_tag.evaluate(cess_sents[train+1:])
print("evaluate tagger: ")
print(bi_tag.accuracy(cess_sents[train+1:]))

# Using the tagger.
print("use tagger: ")
print(bi_tag.tag(sentence.split(" ")))

import fibo
fibo.fib(4)

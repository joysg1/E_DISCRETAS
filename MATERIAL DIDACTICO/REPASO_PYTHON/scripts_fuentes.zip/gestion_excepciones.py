while True:
    try:
        x = int(input("Por favor ingrese un número: "))
        break
    except ValueError:
        print("Oops!  Ese no es un número valido.  Intente de nuevo...")

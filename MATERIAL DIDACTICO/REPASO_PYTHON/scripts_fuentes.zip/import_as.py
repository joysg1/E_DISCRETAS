import fibo as fib
fib.fib(500)

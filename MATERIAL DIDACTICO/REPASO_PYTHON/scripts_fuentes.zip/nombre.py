nombre = input("Ingrese su nombre: ")
print("Su nombre es " + nombre)

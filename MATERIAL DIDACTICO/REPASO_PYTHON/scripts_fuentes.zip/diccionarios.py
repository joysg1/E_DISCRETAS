directorio_tel = {'juan' : 64835182, 'pedro' : 2309364}
print(directorio_tel['juan'])

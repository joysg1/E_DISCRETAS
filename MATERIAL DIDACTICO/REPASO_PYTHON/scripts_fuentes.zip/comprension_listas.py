vec = [-4, -2, 0, 2, 4]

# crear una lista nueva con valores doblados
print([x*2 for x in vec])

# filtrar la lista para excluir números negativos
print([x for x in vec if x >= 0])

# aplicar una función a todos los elementos
print([abs(x) for x in vec])

# llamar un metodo en cada elemento
frutasfrescas = ['  guineo', '  mango ', ' maracuyá ']
print([letra.strip() for letra in frutasfrescas])

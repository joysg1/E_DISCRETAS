import networkx as nx

GD = nx.DiGraph()




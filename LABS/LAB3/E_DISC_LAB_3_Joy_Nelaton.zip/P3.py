# Asignacion de tuplas a listas

con_tub1 = [(67,20), (4,4,5), (24,84,75)]
con_tub2 = [("papel", "roca"), ("tijeras", "papel"), ("roca", "tijeras")]
con_tub3 = [(98, 89), ("a","b"), ("@", "#")]
con_tub4 = [(35, "agua"), ("suelo", 942, "***"), ("ropa")]
con_tub5 = [(1,2), (20,50), (1,4,8), (8,8)]


# Impresion de las listas con las tuplas

print(con_tub1)
print(con_tub2)
print(con_tub3)
print(con_tub4)
print(con_tub5)

tup1 = (1,2)   # Asignacion de valores a la tup1

print(tup1)    # Impresion de la tup1

tup2 = ("metal", "hierro") # Asignacion de valores a la tup2

print(tup2) # Impresion de la tup2

tup3 = ("arbol", "hojas",7) # Asignacion de valores a la tup3

print(tup3) # Impresion de la tup3

subin1 = "\u2082"  # Variables para alojar los subindices 
subin2 = "\u2085"

t1 = subin1 + "P" + subin2 # Variable para concatenar los subindices y la letra

t2 = "5" + "\u00B2" # Variable para concatenar el 5 y el superindice

tup4 = (t1, t2) # Asignacion de variables a la tup4

print(tup4) # Impresion de la tup4


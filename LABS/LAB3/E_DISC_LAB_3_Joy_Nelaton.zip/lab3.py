from lab3_funciones import *
